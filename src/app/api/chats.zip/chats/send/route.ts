
// src/app/api/chat/send/route.ts
import { NextResponse } from "next/server";

export async function POST(request: Request) {
  try {
    const authHeader = request.headers.get("Authorization")
    if (!authHeader?.startsWith("Bearer ")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const accessToken = authHeader.split(" ")[1]
    const formData = await request.formData();

    // Forward the form data directly to your backend API
    const res = await fetch("https://6jnqmj85-8080.inc1.devtunnels.ms/api/chat/send", {
      method: "POST",
      body: formData, // already in FormData format
      headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${accessToken}`,
              },
    });

    const data = await res.json();

    if (!res.ok) {
      return NextResponse.json({ error: data?.error || "Failed to send message" }, { status: res.status });
    }

    return NextResponse.json(data);
  } catch (error: any) {
    console.error("Error sending chat message:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
